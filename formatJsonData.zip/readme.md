-- Instalation --

Need package files (package-lock.json and package.json)

1. npm install

2. savecookie.js

3. apnacollage.js

4. formatJsondata.js

5.  